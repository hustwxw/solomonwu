$(document).ready(function() {

	// 头寸
	var option1 = {
		"legend": {
			"show": false
		},
		"grid": {},
		"calculable": true,
		"series": [{
			"name": "总量",
			"type": "pie",
			"z": 0,
			"center": ["50%", "50%"],
			"radius": ["0%", "100%"],
			"data": [{
				"value": 3,
				"name": "可用",
				"itemStyle": {
					"normal": {
						"color": "#f39800"
					}
				},
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": false
			}, {
				"value": 2,
				"name": "不可用",
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": false,
				"itemStyle": {
					"normal": {
						"color": "#00b7ee"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart1").get(0));
	echartsContainer.setOption(option1);

	// 净资产收益率
	var option2 = {
		"legend": {
			"show": false
		},
		"grid": {},
		"title": {
			"textStyle": {
				"color": "#f3374b",
				"fontSize": window.FONTSIZE * 0.30, //在设计图上改字体是40px，750px的宽度比例
				"fontWeight": "normal"
			},
			"x": "center",
			"y": "45%",
			"text": "72.02%",
			"itemGap": 2,
			"padding": [0, 5]
		},
		"calculable": true,
		"series": [{
			"type": "pie",
			"z": 0,
			"center": ["50%", "50%"],
			"radius": ["78%", "100%"],
			"data": [{
				"value": 3,
				"name": "年度累计",
				"itemStyle": {
					"normal": {
						"color": "#f39800"
					}
				},
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": false
			}, {
				"value": 2,
				"name": "年度预算",
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": false,
				"itemStyle": {
					"normal": {
						"color": "#00b7ee"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart2").get(0));
	echartsContainer.setOption(option2);

	// 收入
	var option3 = {
		"legend": {
			"show": false
		},
		"grid": {},
		"title": {
			"textStyle": {
				"color": "#f3374b",
				"fontSize": window.FONTSIZE * 0.30, //在设计图上改字体是40px，750px的宽度比例
				"fontWeight": "normal"
			},
			"subtextStyle": {
				"rich": {
					"a": {
						"color": "#84878e",
						"fontSize": window.FONTSIZE * 0.18,
						"fontWeight": "normal",
						"lineHeight": 15
					},
					"b": {
						"color": "#84878e",
						"fontSize": window.FONTSIZE * 0.18,
						"fontWeight": "normal",
						"lineHeight": 15
					}
				}
			},
			"x": "center",
			"x": "center",
			"y": "35%",
			"text": "2.23%",
			"subtext": "{a|年度累计}\n{b|执行率}",
			"itemGap": 2,
			"padding": [0, 5]
		},
		"calculable": true,
		"series": [{
			"name": "总量",
			"type": "pie",
			"z": 0,
			"center": ["50%", "50%"],
			"radius": ["78%", "100%"],
			"data": [{
				"value": 3,
				"name": "年度累计",
				"itemStyle": {
					"normal": {
						"color": "#f39800"
					}
				},
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": false
			}, {
				"value": 2,
				"name": "年度预算",
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": false,
				"itemStyle": {
					"normal": {
						"color": "#00b7ee"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart3").get(0));
	echartsContainer.setOption(option3);

	// 资产周转率
	var option4 = {
		"legend": {
			"show": false
		},
		"grid": {},
		"title": {
			"textStyle": {
				"color": "#f3374b",
				"fontSize": window.FONTSIZE * 0.30, //在设计图上改字体是40px，750px的宽度比例
				"fontWeight": "normal"
			},
			"x": "center",
			"y": "45%",
			"text": "46.02%",
			"itemGap": 2,
			"padding": [0, 5]
		},
		"calculable": true,
		"series": [{
			"type": "pie",
			"z": 0,
			"center": ["50%", "50%"],
			"radius": ["78%", "100%"],
			"data": [{
				"value": 3,
				"name": "年度累计",
				"itemStyle": {
					"normal": {
						"color": "#f39800"
					}
				},
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": false
			}, {
				"value": 2,
				"name": "年度预算",
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": false,
				"itemStyle": {
					"normal": {
						"color": "#00b7ee"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart4").get(0));
	echartsContainer.setOption(option4);
});