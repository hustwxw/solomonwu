$(document).ready(function() {

	var option1 = {
		legend: {
			show: true,
			right: '-10%',
			itemWidth: window.FONTSIZE * 0.3,
			itemHeight: window.FONTSIZE * 0.15,
			textStyle: {
				fontSize: window.FONTSIZE * 0.16,
				color: '#333'
			},
			itemGap: 0
		},
		"grid": {
			"top": "25%",
			"left": "5%",
			"right": "5%",
			"bottom": "0%",
			"containLabel": true
		},
		"xAxis": {
			"type": "category",
			"data": ['海航科技', '海航旅业', '海航资本', '海航现代物流', '海航新传媒', '海航创新金融'],
			axisLabel: {
				interval: 0,
				rotate: 20,
				margin: 10,
				textStyle: {
					color: "#84878e"
				}
			},
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		},
		"yAxis": [{
			"type": "value",
			"name": "亿元",
			"position": "left",
			"splitNumber": 5,
			"nameLocation": "end",
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		}],
		"series": [{
			"name": "生产经营收入年累计",
			"type": "bar",
			"data": [726.2, 726.2, 726.2, 746.2, 746.2, 746.2],
			"barWidth": 3,
			"itemStyle": {
				"normal": {
					"color": "red"
				}
			},
			"barGap": "200%"
		}, {
			"name": "重点企业计财口径年累计收入",
			"type": "bar",
			"data": [204.12, 204.12, 236.14, 245.2, 245.2, 320],
			"barWidth": 3,
			"itemStyle": {
				"normal": {
					"color": "green"
				}
			},
			"barGap": "200%"
		}, {
			"name": "产业集团计财口径年累计收入",
			"type": "bar",
			"data": [204.12, 204.12, 236.14, 245.2, 245.2, 245.2],
			"barWidth": 3,
			"itemStyle": {
				"normal": {
					"color": "yellow"
				}
			},
			"barGap": "200%"
		}, {
			"name": "年累计预算",
			"type": "bar",
			"data": [204.12, 204.12, 236.14, 245.2, 245.2, 245.2, 616.2, 616.2, 616.2, 616.2, 616.2, 726.2],
			"barWidth": 3,
			"itemStyle": {
				"normal": {
					"color": "blue"
				}
			},
			"barGap": "200%"
		}],
		"tooltip": {
			"show": true,
			"trigger": "axis"
		}
	}
	var echartsContainer = echarts.init($("#chart1").get(0));
	echartsContainer.setOption(option1);

	var option2 = {
		legend: {
			show: true,
			right: '-10%',
			itemWidth: window.FONTSIZE * 0.3,
			itemHeight: window.FONTSIZE * 0.15,
			textStyle: {
				fontSize: window.FONTSIZE * 0.16,
				color: '#333'
			},
			itemGap: 0
		},
		"grid": {
			"top": "25%",
			"left": "5%",
			"right": "5%",
			"bottom": "0%",
			"containLabel": true
		},
		"xAxis": {
			"type": "category",
			"data": ['海航科技', '海航旅业', '海航资本', '海航现代物流', '海航新传媒', '海航创新金融'],
			axisLabel: {
				interval: 0,
				rotate: 20,
				margin: 10,
				textStyle: {
					color: "#84878e"
				}
			},
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		},
		"yAxis": [{
			"type": "value",
			"name": "亿元",
			"position": "left",
			"splitNumber": 5,
			"nameLocation": "end",
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		}],
		"series": [{
			"name": "生产经营收入年累计",
			"type": "bar",
			"data": [726.2, 726.2, 726.2, 746.2, 746.2, 746.2],
			"barWidth": 3,
			"itemStyle": {
				"normal": {
					"color": "red"
				}
			},
			"barGap": "200%"
		}, {
			"name": "重点企业计财口径年累计收入",
			"type": "bar",
			"data": [204.12, 204.12, 236.14, 245.2, 245.2, 320],
			"barWidth": 3,
			"itemStyle": {
				"normal": {
					"color": "green"
				}
			},
			"barGap": "200%"
		}, {
			"name": "产业集团计财口径年累计收入",
			"type": "bar",
			"data": [204.12, 204.12, 236.14, 245.2, 245.2, 245.2],
			"barWidth": 3,
			"itemStyle": {
				"normal": {
					"color": "yellow"
				}
			},
			"barGap": "200%"
		}, {
			"name": "年累计预算",
			"type": "bar",
			"data": [204.12, 204.12, 236.14, 245.2, 245.2, 245.2, 616.2, 616.2, 616.2, 616.2, 616.2, 726.2],
			"barWidth": 3,
			"itemStyle": {
				"normal": {
					"color": "blue"
				}
			},
			"barGap": "200%"
		}],
		"tooltip": {
			"show": true,
			"trigger": "axis"
		}
	}
	var echartsContainer = echarts.init($("#chart2").get(0));
	echartsContainer.setOption(option2);

	var option3 = {
		legend: {
			show: true,
			right: '-10%',
			itemWidth: window.FONTSIZE * 0.3,
			itemHeight: window.FONTSIZE * 0.15,
			textStyle: {
				fontSize: window.FONTSIZE * 0.16,
				color: '#333'
			},
			itemGap: 0
		},
		"grid": {
			"top": "25%",
			"left": "5%",
			"right": "5%",
			"bottom": "0%",
			"containLabel": true
		},
		"xAxis": {
			"type": "category",
			"data": ['海航科技', '海航旅业', '海航资本', '海航现代物流', '海航新传媒', '海航创新金融'],
			axisLabel: {
				interval: 0,
				rotate: 20,
				margin: 10,
				textStyle: {
					color: "#84878e"
				}
			},
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		},
		"yAxis": [{
			"type": "value",
			"name": "亿元",
			"position": "left",
			"splitNumber": 5,
			"nameLocation": "end",
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		}],
		"series": [{
			"name": "生产经营收入年累计",
			"type": "bar",
			"data": [726.2, 726.2, 726.2, 746.2, 746.2, 746.2],
			"barWidth": 3,
			"itemStyle": {
				"normal": {
					"color": "red"
				}
			},
			"barGap": "200%"
		}, {
			"name": "重点企业计财口径年累计收入",
			"type": "bar",
			"data": [204.12, 204.12, 236.14, 245.2, 245.2, 320],
			"barWidth": 3,
			"itemStyle": {
				"normal": {
					"color": "green"
				}
			},
			"barGap": "200%"
		}, {
			"name": "产业集团计财口径年累计收入",
			"type": "bar",
			"data": [204.12, 204.12, 236.14, 245.2, 245.2, 245.2],
			"barWidth": 3,
			"itemStyle": {
				"normal": {
					"color": "yellow"
				}
			},
			"barGap": "200%"
		}, {
			"name": "年累计预算",
			"type": "bar",
			"data": [204.12, 204.12, 236.14, 245.2, 245.2, 245.2, 616.2, 616.2, 616.2, 616.2, 616.2, 726.2],
			"barWidth": 3,
			"itemStyle": {
				"normal": {
					"color": "blue"
				}
			},
			"barGap": "200%"
		}],
		"tooltip": {
			"show": true,
			"trigger": "axis"
		}
	}
	var echartsContainer = echarts.init($("#chart3").get(0));
	echartsContainer.setOption(option3);

	var option4 = {
		legend: {
			show: true,
			right: '-10%',
			itemWidth: window.FONTSIZE * 0.3,
			itemHeight: window.FONTSIZE * 0.15,
			textStyle: {
				fontSize: window.FONTSIZE * 0.16,
				color: '#333'
			},
			itemGap: 0
		},
		"grid": {
			"top": "25%",
			"left": "5%",
			"right": "5%",
			"bottom": "0%",
			"containLabel": true
		},
		"xAxis": {
			"type": "category",
			"data": ['海航科技', '海航旅业', '海航资本', '海航现代物流', '海航新传媒', '海航创新金融'],
			axisLabel: {
				interval: 0,
				rotate: 20,
				margin: 10,
				textStyle: {
					color: "#84878e"
				}
			},
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		},
		"yAxis": [{
			"type": "value",
			"name": "亿元",
			"position": "left",
			"splitNumber": 5,
			"nameLocation": "end",
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		}],
		"series": [{
			"name": "生产经营收入年累计",
			"type": "bar",
			"data": [726.2, 726.2, 726.2, 746.2, 746.2, 746.2],
			"barWidth": 3,
			"itemStyle": {
				"normal": {
					"color": "red"
				}
			},
			"barGap": "200%"
		}, {
			"name": "重点企业计财口径年累计收入",
			"type": "bar",
			"data": [204.12, 204.12, 236.14, 245.2, 245.2, 320],
			"barWidth": 3,
			"itemStyle": {
				"normal": {
					"color": "green"
				}
			},
			"barGap": "200%"
		}, {
			"name": "产业集团计财口径年累计收入",
			"type": "bar",
			"data": [204.12, 204.12, 236.14, 245.2, 245.2, 245.2],
			"barWidth": 3,
			"itemStyle": {
				"normal": {
					"color": "yellow"
				}
			},
			"barGap": "200%"
		}, {
			"name": "年累计预算",
			"type": "bar",
			"data": [204.12, 204.12, 236.14, 245.2, 245.2, 245.2, 616.2, 616.2, 616.2, 616.2, 616.2, 726.2],
			"barWidth": 3,
			"itemStyle": {
				"normal": {
					"color": "blue"
				}
			},
			"barGap": "200%"
		}],
		"tooltip": {
			"show": true,
			"trigger": "axis"
		}
	}
	var echartsContainer = echarts.init($("#chart4").get(0));
	echartsContainer.setOption(option4);

});