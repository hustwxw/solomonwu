var swiper = new Swiper('.relative_index', {
	slidesPerView: 2.2,
	spaceBetween: 15,
	freeMode: true
});

$(document).ready(function() {

	// 性别
	var option1 = {
		"legend": {
			"show": false
		},
		"grid": {},
		"label": {
			"formatter": function(ele) {
				return {
					"男性": "1234人",
					"女性": "2134人"
				}[ele.name]
			},
			"normal": {
				"show": true,
			},
			"emphasis": {
				"show": false
			}
		},
		"labelLine": {
			"normal": {
				"show": true
			},
			"emphasis": {
				"show": false
			}
		},
		"calculable": true,
		"series": [{
			"type": "pie",
			"z": 0,
			"center": ["50%", "50%"],
			"radius": ["65%", "80%"],
			"data": [{
				"value": 1368.25,
				"name": "女性",
				"itemStyle": {
					"normal": {
						"color": "#2FB4FC"
					}
				},
				"tooltip": {
					"show": true
				},
				"hoverAnimation": true,
				"stack": "各业态月收入"
			}, {
				"value": 2368,
				"name": "男性",
				"tooltip": {
					"show": true
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#f3374b"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart1").get(0));
	echartsContainer.setOption(option1);

	// 年龄
	var option2 = {
		backgroundColor: '#ffffff',
		grid: {
			left: '1%',
			right: '12%',
			bottom: '10%',
			top: '15%',
			containLabel: true
		},

		tooltip: {
			show: "true",
			trigger: 'axis',
			axisPointer: { // 坐标轴指示器，坐标轴触发有效
				type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
			}
		},
		xAxis: {
			type: 'value',
			axisTick: {
				show: true
			},
			axisLine: {
				show: true,
				lineStyle: {
					color: '#84878e',
				}
			},
			splitLine: {
				show: true
			},
			name: '%',
			max: 100
		},
		yAxis: {
			type: 'category',
			axisTick: {
				show: false
			},
			axisLine: {
				show: true,
				lineStyle: {
					color: '#84878e',
				}
			},
			data: ['30岁以下', '30-40岁', '40-50岁', '50岁以上'].reverse()
		},
		series: [{
			type: 'bar',

			itemStyle: {
				normal: {
					show: true,
					color: '#f3374b',
					borderWidth: 0
				}
			},
			barGap: '80%',
			barCategoryGap: '50%',
			label: {
				show: true,
				position: 'right',
				fontSize: window.FONTSIZE * 0.20,
				formatter: function(ele) {
					return ele.data + "%";
				}
			},
			data: [40, 20, 30, 10]
		}]
	};
	var echartsContainer = echarts.init($("#chart2").get(0));
	echartsContainer.setOption(option2);

	// 区域
	var option3 = {
		"legend": {
			"show": true,
			"orient": "vertical",
			"right": "5%",
			"top": "25%",
			"itemGap": 50,
			"formatter": function(ele) {
				return {
					"境内": "境内：3214人",
					"境外": "境外：21341人"
				}[ele]
			},
			"textStyle": {
				"color": "#333",
				"fontSize": window.FONTSIZE * 0.25
			}
		},
		"label": {
			"normal": {
				"show": true
			},
			"emphasis": {
				"show": false
			},
			"formatter": function(ele) {
				return {
					"境内": "11.22%",
					"境外": "22.33%"
				}[ele.name]
			},
		},
		"grid": {},
		"title": {
			"textStyle": {
				"color": "#f3374b",
				"fontSize": window.FONTSIZE * 0.4, //在设计图上改字体是40px，750px的宽度比例
				"fontWeight": "normal"
			},
			"subtextStyle": {
				"color": "#84878e",
				"fontSize": window.FONTSIZE * 0.24, //在设计图上改字体是24px，750px的宽度比例
				"fontWeight": "normal"
			},
			"x": "center",
			"y": "35%",
			"text": "60.6%",
			"subtext": "完成年度预算",
			show: false
		},
		"calculable": true,
		"series": [{
			"type": "pie",
			"z": 0,
			"center": ["30%", "50%"],
			"radius": ["50%", "65%"],
			"labelLine": {
				"length": 2,
				"length2": 5,
				"show": true
			},
			"data": [{
				"value": 1368.25,
				"name": "境内",
				"itemStyle": {
					"normal": {
						"color": "#33cc34"
					}
				},
				"tooltip": {
					"show": true
				},
				"hoverAnimation": true,
				"stack": "各业态月收入"
			}, {
				"value": 2368,
				"name": "境外",
				"tooltip": {
					"show": true
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#f3374b"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart3").get(0));
	echartsContainer.setOption(option3);

	// 用工形式
	var option5 = {
		"legend": {
			"show": true,
			"orient": "vertical",
			"right": "2%",
			"top": "25%",
			"itemGap": 50,
			"formatter": function(ele) {
				return {
					"合同工": "合同工：321人",
					"其他用工": "其他用工：213人"
				}[ele]
			},
			"textStyle": {
				"color": "#333",
				"fontSize": window.FONTSIZE * 0.25
			}
		},
		"label": {
			"normal": {
				"show": true
			},
			"emphasis": {
				"show": false
			},
			"formatter": function(ele) {
				return {
					"合同工": "11.22%",
					"其他用工": "22.33%"
				}[ele.name]
			},
		},
		"grid": {},
		"calculable": true,
		"series": [{
			"type": "pie",
			"z": 0,
			"center": ["30%", "50%"],
			"radius": ["50%", "65%"],
			"labelLine": {
				"length": 2,
				"length2": 5,
				"show": true
			},
			"data": [{
				"value": 1368.25,
				"name": "其他用工",
				"itemStyle": {
					"normal": {
						"color": "#33cc34"
					}
				},
				"tooltip": {
					"show": true
				},
				"hoverAnimation": true,
				"stack": "各业态月收入"
			}, {
				"value": 2368,
				"name": "合同工",
				"tooltip": {
					"show": true
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#f3374b"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart5").get(0));
	echartsContainer.setOption(option5);

	// 学历
	var option6 = {
		"legend": {
			"show": true,
			"orient": "vertical",
			"right": "2%",
			"top": "20%",
			"itemGap": 10,
			"formatter": function(ele) {
				return {
					"硕士及以上": "硕士及以上：10%",
					"本科": "本科：20%",
					"大专": "大专：30%",
					"大专以下": "大专以下：20%",
					"未知": "未知：10%"
				}[ele]
			},
			"textStyle": {
				"color": "#333",
				"fontSize": window.FONTSIZE * 0.25
			}
		},
		"grid": {},
		"calculable": true,
		"series": [{
			"type": "pie",
			"z": 0,
			"center": ["30%", "50%"],
			"radius": ["50%", "65%"],
			"labelLine": {
				"length": 2,
				"length2": 5,
				"show": false
			},
			label: {
				show: false
			},
			"data": [{
				"value": 1368.25,
				"name": "硕士及以上",
				"itemStyle": {
					"normal": {
						"color": "#C8A558"
					}
				},
				"tooltip": {
					"show": true
				},
				"hoverAnimation": true,
				"stack": "各业态月收入"
			}, {
				"value": 2368,
				"name": "本科",
				"tooltip": {
					"show": true
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#f3374b"
					}
				}
			}, {
				"value": 2368,
				"name": "大专",
				"tooltip": {
					"show": true
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#f20BCFC"
					}
				}
			}, {
				"value": 2368,
				"name": "大专以下",
				"tooltip": {
					"show": true
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#93C728"
					}
				}
			}, {
				"value": 2368,
				"name": "未知",
				"tooltip": {
					"show": true
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#FD29FC"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart6").get(0));
	echartsContainer.setOption(option6);

	// 学历
	var option7 = {
		"legend": {
			"show": true,
			"orient": "vertical",
			"right": "2%",
			"top": "20%",
			"itemGap": 10,
			"formatter": function(ele) {
				return {
					"客舱服务类": "客舱服务类：10%",
					"飞行类": "飞行类：20%",
					"航空运行控制类": "航空运行控制类：30%",
					"航空维修工程类": "航空维修工程类：20%",
					"地勤服务类": "地勤服务类：10%"
				}[ele]
			},
			"textStyle": {
				"color": "#333",
				"fontSize": window.FONTSIZE * 0.25
			}
		},
		"grid": {},
		"calculable": true,
		"series": [{
			"type": "pie",
			"z": 0,
			"center": ["30%", "50%"],
			"radius": ["50%", "65%"],
			"labelLine": {
				"length": 2,
				"length2": 5,
				"show": false
			},
			label: {
				show: false
			},
			"data": [{
				"value": 1368.25,
				"name": "客舱服务类",
				"itemStyle": {
					"normal": {
						"color": "#C8A558"
					}
				},
				"tooltip": {
					"show": true
				},
				"hoverAnimation": true,
				"stack": "各业态月收入"
			}, {
				"value": 2368,
				"name": "飞行类",
				"tooltip": {
					"show": true
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#f3374b"
					}
				}
			}, {
				"value": 2368,
				"name": "航空运行控制类",
				"tooltip": {
					"show": true
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#f20BCFC"
					}
				}
			}, {
				"value": 2368,
				"name": "航空维修工程类",
				"tooltip": {
					"show": true
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#93C728"
					}
				}
			}, {
				"value": 2368,
				"name": "地勤服务类",
				"tooltip": {
					"show": true
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#FD29FC"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart7").get(0));
	echartsContainer.setOption(option7);

	// 外语
	var option8 = {
		"legend": {
			"show": true,
			"orient": "vertical",
			"right": "2%",
			"top": "20%",
			"itemGap": 10,
			"formatter": function(ele) {
				return {
					"CET6及以上": "CET6及以上：10%",
					"CET4": "CET4：20%",
					"其他英语等级": "其他英语等级：30%",
					"其他语种证书": "其他语种证书：20%",
					"无语言等级证书": "无语言等级证书：10%"
				}[ele]
			},
			"textStyle": {
				"color": "#333",
				"fontSize": window.FONTSIZE * 0.25
			}
		},
		"grid": {},
		"calculable": true,
		"series": [{
			"type": "pie",
			"z": 0,
			"center": ["30%", "50%"],
			"radius": ["50%", "65%"],
			"labelLine": {
				"length": 2,
				"length2": 5,
				"show": false
			},
			label: {
				show: false
			},
			"data": [{
				"value": 1368.25,
				"name": "CET6及以上",
				"itemStyle": {
					"normal": {
						"color": "#C8A558"
					}
				},
				"tooltip": {
					"show": true
				},
				"hoverAnimation": true,
				"stack": "各业态月收入"
			}, {
				"value": 2368,
				"name": "CET4",
				"tooltip": {
					"show": true
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#f3374b"
					}
				}
			}, {
				"value": 2368,
				"name": "其他英语等级",
				"tooltip": {
					"show": true
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#f20BCFC"
					}
				}
			}, {
				"value": 2368,
				"name": "其他语种证书",
				"tooltip": {
					"show": true
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#93C728"
					}
				}
			}, {
				"value": 2368,
				"name": "无语言等级证书",
				"tooltip": {
					"show": true
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#FD29FC"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart8").get(0));
	echartsContainer.setOption(option8);

	// 金字塔
	var max = 16;
	var conf = {
		grid: {

		},
		tooltip: {
			trigger: 'item',
			formatter: "{a} <br/>{b} : {c}%"
		},
		calculable: true,
		series: [{
			name: '金字塔',
			top: 15,
			left: 25,
			type: 'funnel',
			// x: '10%',
			width: '80%',
			height: '80%',
			// gap: 1,
			funnelAlign: 'center',
			sort: 'ascending',
			itemStyle: {
				normal: {
					color: function(ele) {
						var map = {
							'M1': '#d4d392',
							'M2': '#f3d13a',
							'M3': '#99c383',
							'M4': '#00b163',
							'M5': '#01a04e',
							'M6': '#018cb7',
							'M7': '#0066b8',
							'M8': '#cb9fd4',
							'M9': '#c65c9a',
							'M10': '#f87793',
							'M11': '#dd2142',
							'M12': '#ee6889',
							'M13': '#f55348',
							'M14': '#fd2101',
							'M15': '#de2700',
							'M16': '#cf0a02'
						};
						return map[ele.data.name] || "#ff0000";
					},
					label: {
						position: 'right'
					}
				}
			},
			data: (function() {

				var pre = "M";
				var arr = [];
				for (var i = 1; i <= max; i++) {
					arr.push({
						name: pre + i,
						value: (max + 1 - i) * 10
					});
				}

				return arr;

			})()
		}]

	}

	var echartsContainer = echarts.init($("#chart4").get(0));
	echartsContainer.setOption(conf);

});