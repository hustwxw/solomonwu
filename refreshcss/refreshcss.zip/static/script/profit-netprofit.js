// 关联指标滑动
var swiper = new Swiper('#relative', {
	slidesPerView: 2.2,
	spaceBetween: 15,
	freeMode: true
});

$(document).ready(function() {

	//echarts渲染

	// 当月预算完成情况
	var option1 = {
		"legend": {
			"show": false
		},
		"grid": {},
		"title": {
			"subtextStyle": {
				"color": "#f3374b",
				"fontSize": window.FONTSIZE * 0.4, //在设计图上改字体是40px，750px的宽度比例
				"fontWeight": "normal"
			},
			"textStyle": {
				"color": "#84878e",
				"fontSize": window.FONTSIZE * 0.24, //在设计图上改字体是24px，750px的宽度比例
				"fontWeight": "normal"
			},
			"x": "center",
			"y": "35%",
			"subtext": "60.6%",
			"text": "完成当月预算"
		},
		"calculable": true,
		"series": [{
			"name": "总量",
			"type": "pie",
			"z": 0,
			"center": ["50%", "50%"],
			"radius": ["65%", "80%"],
			"data": [{
				"value": 1368.25,
				"name": "年度累计",
				"itemStyle": {
					"normal": {
						"color": "#f3374b"
					}
				},
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": true,
				"stack": "各业态月收入"
			}, {
				"value": 2368,
				"name": "年度预算",
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#f5f5f5"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart1").get(0));
	echartsContainer.setOption(option1);

	// 年度预算完成情况
	var option2 = {
		"legend": {
			"show": false
		},
		"grid": {},
		"title": {
			"subtextStyle": {
				"color": "#f3374b",
				"fontSize": window.FONTSIZE * 0.4, //在设计图上改字体是40px，750px的宽度比例
				"fontWeight": "normal"
			},
			"textStyle": {
				"color": "#84878e",
				"fontSize": window.FONTSIZE * 0.24, //在设计图上改字体是24px，750px的宽度比例
				"fontWeight": "normal"
			},
			"x": "center",
			"y": "35%",
			"subtext": "60.6%",
			"text": "完成年度预算"
		},
		"calculable": true,
		"series": [{
			"name": "总量",
			"type": "pie",
			"z": 0,
			"center": ["50%", "50%"],
			"radius": ["65%", "80%"],
			"data": [{
				"value": 9368.25,
				"name": "年度累计",
				"itemStyle": {
					"normal": {
						"color": "#f3374b"
					}
				},
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": true,
				"stack": "各业态月收入"
			}, {
				"value": 2368,
				"name": "年度预算",
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#f5f5f5"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart2").get(0));
	echartsContainer.setOption(option2);

	// 产业集团
	var option3 = {
		backgroundColor: '#ffffff',
		legend: {
			show: true,
			right: '0%',
			top: '0%',
			itemWidth: window.FONTSIZE * 0.3,
			itemHeight: window.FONTSIZE * 0.15,
			textStyle: {
				fontSize: window.FONTSIZE * 0.16,
				color: '#333'
			}
		},
		grid: {
			left: '1%',
			right: '12%',
			bottom: '10%',
			top: '15%',
			containLabel: true
		},

		tooltip: {
			show: "true",
			trigger: 'axis',
			axisPointer: { // 坐标轴指示器，坐标轴触发有效
				type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
			}
		},
		xAxis: {
			type: 'value',
			axisTick: {
				show: true
			},
			axisLine: {
				show: true,
				lineStyle: {
					color: '#84878e',
				}
			},
			splitLine: {
				show: true
			},
			name: '亿元'
		},
		yAxis: [{
				type: 'category',
				axisTick: {
					show: false
				},
				axisLine: {
					show: true,
					lineStyle: {
						color: '#84878e',
					}
				},
				data: ['海航资本', '海航实业', '海航现代物流', '海航科技', '海航创新金融', '海航新传媒'].reverse()
			}, {
				type: 'category',
				axisLine: {
					show: false
				},
				axisTick: {
					show: false
				},
				axisLabel: {
					show: false
				},
				splitArea: {
					show: false
				},
				splitLine: {
					show: false
				},
				data: ['海航资本', '海航实业', '海航现代物流', '海航科技', '海航创新金融', '海航新传媒'].reverse()
			},

		],
		series: [{
			name: '预算',
			type: 'bar',
			yAxisIndex: 1,

			itemStyle: {
				normal: {
					show: true,
					color: '#f3374b',
					borderWidth: 0
				}
			},
			barGap: '80%',
			barCategoryGap: '50%',
			label: {
				show: true,
				position: 'right',
				fontSize: window.FONTSIZE * 0.12
			},
			data: [120, 132, -101, 134, 990, 230]
		}, {
			name: '净利润',
			type: 'bar',
			yAxisIndex: 1,

			itemStyle: {
				normal: {
					show: true,
					color: '#f39800',
					borderWidth: 0
				}
			},
			label: {
				show: true,
				position: 'right',
				fontSize: window.FONTSIZE * 0.12
			},
			barGap: '80%',
			barCategoryGap: '50%',
			data: [-320, 432, -911, 613, -330, -130]
		}]
	};
	var echartsContainer = echarts.init($("#chart3").get(0));
	echartsContainer.setOption(option3);

	// 时间
	var option4 = {
		legend: {
			show: true,
			right: '0%',
			top: '0%',
			itemWidth: window.FONTSIZE * 0.3,
			itemHeight: window.FONTSIZE * 0.15,
			textStyle: {
				fontSize: window.FONTSIZE * 0.16,
				color: '#333'
			}
		},
		"grid": {
			"top": "15%",
			"left": "5%",
			"right": "5%",
			"bottom": "5%",
			"containLabel": true
		},
		"xAxis": {
			"type": "category",
			"data": ["1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月"],
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			},
			axisLabel: {
				interval: 0,
				margin: 10,
				textStyle: {
					color: "#84878e"
				}
			}
		},
		"yAxis": [{
			"type": "value",
			"name": "亿元",
			"position": "left",
			"splitNumber": 5,
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		}],
		"series": [{
			"name": "收入",
			"type": "bar",
			"data": [726.2, 726.2, 726.2, 746.2, 746.2, 746.2, 746.2, 746.2, 746.2, 746.2, 746.2, 746.2],
			"barWidth": 5,
			"itemStyle": {
				"normal": {
					"color": "#f3374b"
				}
			},
			"barGap": "30%"
		}, {
			"name": "预算",
			"type": "bar",
			"data": [204.12, 204.12, 236.14, 245.2, 245.2, 245.2, 616.2, 616.2, 616.2, 616.2, 616.2, 726.2],
			"barWidth": 5,
			"itemStyle": {
				"normal": {
					"color": "#f39800"
				}
			},
			"barGap": "30%"
		}],
		"tooltip": {
			"show": true,
			"trigger": "axis"
		}
	}
	var echartsContainer = echarts.init($("#chart4").get(0));
	echartsContainer.setOption(option4);

	// 境内外
	// 当月预算完成情况
	var option5 = {
		"legend": {
			"show": false
		},
		"grid": {},
		"title": {
			"subtextStyle": {
				"color": "#84878e",
				"fontSize": window.FONTSIZE * 0.28, //在设计图上改字体是40px，750px的宽度比例
				"fontWeight": "normal"
			},
			"textStyle": {
				"color": "#84878e",
				"fontSize": window.FONTSIZE * 0.28, //在设计图上改字体是24px，750px的宽度比例
				"fontWeight": "normal"
			},
			"x": "center",
			"y": "42%",
			"subtext": "境内:45.34%",
			"text": "境外:45.68%"
		},
		"calculable": true,
		"series": [{
			"name": "总量",
			"type": "pie",
			"z": 0,
			"center": ["50%", "50%"],
			"radius": ["65%", "80%"],
			"data": [{
				"value": 1368.25,
				"name": "年度累计",
				"itemStyle": {
					"normal": {
						"color": "#f3374b"
					}
				},
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": true,
				"stack": "各业态月收入"
			}, {
				"value": 2368,
				"name": "年度预算",
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#20BCFA"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart5").get(0));
	echartsContainer.setOption(option5);

	// 境内外同比环比四个圈圈
	var option6 = {
		"legend": {
			"show": false
		},
		"grid": {},
		"title": {
			"subtextStyle": {
				"color": "#33cc34",
				"fontSize": window.FONTSIZE * 0.2, //在设计图上改字体是40px，750px的宽度比例
				"fontWeight": "normal"
			},
			"textStyle": {
				"color": "#84878e",
				"fontSize": window.FONTSIZE * 0.2, //在设计图上改字体是24px，750px的宽度比例
				"fontWeight": "normal"
			},
			"x": "center",
			"y": "30%",
			"subtext": "45.34%",
			"text": "同比"
		},
		"calculable": true,
		"series": [{
			"name": "总量",
			"type": "pie",
			"z": 0,
			"center": ["50%", "50%"],
			"radius": ["65%", "80%"],
			"data": [{
				"value": 1368.25,
				"name": "年度累计",
				"itemStyle": {
					"normal": {
						"color": "#33cc34"
					}
				},
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": true,
				"stack": "各业态月收入"
			}, {
				"value": 2368,
				"name": "年度预算",
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#f5f5f5"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart6").get(0));
	echartsContainer.setOption(option6);

	var option7 = {
		"legend": {
			"show": false
		},
		"grid": {},
		"title": {
			"subtextStyle": {
				"color": "#f3374b",
				"fontSize": window.FONTSIZE * 0.2, //在设计图上改字体是40px，750px的宽度比例
				"fontWeight": "normal"
			},
			"textStyle": {
				"color": "#84878e",
				"fontSize": window.FONTSIZE * 0.2, //在设计图上改字体是24px，750px的宽度比例
				"fontWeight": "normal"
			},
			"x": "center",
			"y": "30%",
			"subtext": "45.34%",
			"text": "环比"
		},
		"calculable": true,
		"series": [{
			"name": "总量",
			"type": "pie",
			"z": 0,
			"center": ["50%", "50%"],
			"radius": ["65%", "80%"],
			"data": [{
				"value": 1368.25,
				"name": "年度累计",
				"itemStyle": {
					"normal": {
						"color": "#f3374b"
					}
				},
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": true,
				"stack": "各业态月收入"
			}, {
				"value": 2368,
				"name": "年度预算",
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#f5f5f5"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart7").get(0));
	echartsContainer.setOption(option7);

	var option8 = {
		"legend": {
			"show": false
		},
		"grid": {},
		"title": {
			"subtextStyle": {
				"color": "#33cc34",
				"fontSize": window.FONTSIZE * 0.2, //在设计图上改字体是40px，750px的宽度比例
				"fontWeight": "normal"
			},
			"textStyle": {
				"color": "#84878e",
				"fontSize": window.FONTSIZE * 0.2, //在设计图上改字体是24px，750px的宽度比例
				"fontWeight": "normal"
			},
			"x": "center",
			"y": "30%",
			"subtext": "45.34%",
			"text": "同比"
		},
		"calculable": true,
		"series": [{
			"name": "总量",
			"type": "pie",
			"z": 0,
			"center": ["50%", "50%"],
			"radius": ["65%", "80%"],
			"data": [{
				"value": 1368.25,
				"name": "年度累计",
				"itemStyle": {
					"normal": {
						"color": "#33cc34"
					}
				},
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": true,
				"stack": "各业态月收入"
			}, {
				"value": 2368,
				"name": "年度预算",
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#f5f5f5"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart8").get(0));
	echartsContainer.setOption(option8);

	var option9 = {
		"legend": {
			"show": false
		},
		"grid": {},
		"title": {
			"subtextStyle": {
				"color": "#f3374b",
				"fontSize": window.FONTSIZE * 0.2, //在设计图上改字体是40px，750px的宽度比例
				"fontWeight": "normal"
			},
			"textStyle": {
				"color": "#84878e",
				"fontSize": window.FONTSIZE * 0.2, //在设计图上改字体是24px，750px的宽度比例
				"fontWeight": "normal"
			},
			"x": "center",
			"y": "30%",
			"subtext": "45.34%",
			"text": "环比"
		},
		"calculable": true,
		"series": [{
			"name": "总量",
			"type": "pie",
			"z": 0,
			"center": ["50%", "50%"],
			"radius": ["65%", "80%"],
			"data": [{
				"value": 1368.25,
				"name": "年度累计",
				"itemStyle": {
					"normal": {
						"color": "#f3374b"
					}
				},
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": true,
				"stack": "各业态月收入"
			}, {
				"value": 2368,
				"name": "年度预算",
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#f5f5f5"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart9").get(0));
	echartsContainer.setOption(option9);

});