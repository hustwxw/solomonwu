$(document).ready(function() {

	// 当月收入
	var option1 = {
		"legend": {
			"show": true,
			"orient": "vertical",
			"right": '-1%',
			"top": '20%',
			"itemWidth": window.FONTSIZE * 0.3,
			"itemHeight": window.FONTSIZE * 0.2,
			"textStyle": {
				"color": "#333",
				"fontSize": window.FONTSIZE * 0.25
			}
		},
		"grid": {},
		"title": {
			"x": "center",
			"y": "center"
		},
		"calculable": true,
		"startAngle": 100,
		"series": [{
			"type": "pie",
			"z": 0,
			"label": {
				"formatter": function(ele) {
					return ele.name + "\n\r(" + ele.percent + "%)";
				}
			},
			"labelLine": {
				"normal": {
					"show": true,
					"length": 5,
					"length2": 5
				},
				"emphasis": {
					"show": false
				}
			},
			"center": ["36%", "50%"],
			"radius": ["35%", "50%"],
			"data": [{
				"value": 340,
				"name": "定期户",
				"itemStyle": {
					"normal": {
						"color": "#C8A558"
					}
				},
				"tooltip": {
					"show": true
				}
			}, {
				"value": 900,
				"name": "融资专户",
				"tooltip": {
					"show": true
				},
				"itemStyle": {
					"normal": {
						"color": "#F03A4F"
					}
				}
			}, {
				"value": 400,
				"name": "保证金户",
				"tooltip": {
					"show": true
				},
				"itemStyle": {
					"normal": {
						"color": "#20BCFC"
					}
				}
			}, {
				"value": 400,
				"name": "结算户",
				"tooltip": {
					"show": true
				},
				"itemStyle": {
					"normal": {
						"color": "#93C728"
					}
				}
			}, {
				"value": 500,
				"name": "其他专户",
				"tooltip": {
					"show": true
				},
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#FD29FC"
					}
				}
			}, {
				"value": 600,
				"name": "财务公司吸存款",
				"tooltip": {
					"show": true
				},
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#2992FC"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart1").get(0));
	echartsContainer.setOption(option1);

});