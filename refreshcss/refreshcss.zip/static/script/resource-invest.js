$(document).ready(function() {

	// 投资项目状态
	var option1 = {
		"legend": {
			"show": true,
			"orient": "vertical",
			"right": "2%",
			"top": "20%",
			"itemGap": 10,
			"textStyle": {
				"color": "#333",
				"fontSize": window.FONTSIZE * 0.25
			}
		},
		"grid": {},
		"title": {
			"textStyle": {
				"color": "#f3374b",
				"fontSize": window.FONTSIZE * 0.4, //在设计图上改字体是40px，750px的宽度比例
				"fontWeight": "normal"
			},
			"subtextStyle": {
				"color": "#84878e",
				"fontSize": window.FONTSIZE * 0.24, //在设计图上改字体是24px，750px的宽度比例
				"fontWeight": "normal"
			},
			"x": "center",
			"y": "35%",
			"text": "60.6%",
			"subtext": "完成年度预算",
			show: false
		},
		"calculable": true,
		"series": [{
			"type": "pie",
			"z": 0,
			"center": ["30%", "50%"],
			"radius": ["50%", "65%"],
			"labelLine": {
				"length": 5,
				"length2": 5,
				"show": true
			},
			"label": {
				show: true,
				formatter: function(ele) {
					return ele.name.substring(0, 3) + '\r\n' + ele.name.substring(3);
				}
			},
			"data": [{
				"value": 1368.25,
				"name": "停止实施",
				"itemStyle": {
					"normal": {
						"color": "#C8A558"
					}
				},
				"tooltip": {
					"show": true
				},
				"hoverAnimation": true,
				"stack": "各业态月收入"
			}, {
				"value": 2368,
				"name": "尚未立项",
				"tooltip": {
					"show": true
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#f3374b"
					}
				}
			}, {
				"value": 2368,
				"name": "已交割",
				"tooltip": {
					"show": true
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#f20BCFC"
					}
				}
			}, {
				"value": 2368,
				"name": "已立项未签约",
				"tooltip": {
					"show": true
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#93C728"
					}
				}
			}, {
				"value": 2368,
				"name": "已签约正在交割",
				"tooltip": {
					"show": true
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#FD29FC"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart1").get(0));
	echartsContainer.setOption(option1);

	// 本月投资项目动态
	var option2 = {
		backgroundColor: '#ffffff',
		grid: {
			left: '1%',
			right: '12%',
			bottom: '10%',
			top: '15%',
			containLabel: true
		},

		tooltip: {
			show: "true",
			trigger: 'axis',
			axisPointer: { // 坐标轴指示器，坐标轴触发有效
				type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
			}
		},
		xAxis: {
			type: 'value',
			axisTick: {
				show: true
			},
			axisLine: {
				show: true,
				lineStyle: {
					color: '#84878e',
				}
			},
			splitLine: {
				show: true
			},
			name: '个',
			max: 100
		},
		yAxis: {
			type: 'category',
			axisTick: {
				show: false
			},
			axisLine: {
				show: true,
				lineStyle: {
					color: '#84878e',
				}
			},
			data: ['新增立项', '新增交割', '新增签约'].reverse()
		},
		series: [{
			type: 'bar',

			itemStyle: {
				normal: {
					show: true,
					color: '#f3374b',
					borderWidth: 0
				}
			},
			barGap: '80%',
			barCategoryGap: '50%',
			label: {
				show: true,
				position: 'right',
				fontSize: window.FONTSIZE * 0.20,
				formatter: function(ele) {
					return ele.data + "个";
				}
			},
			data: [40, 20, 30]
		}]
	};
	var echartsContainer = echarts.init($("#chart2").get(0));
	echartsContainer.setOption(option2);

	// 投资项目本月支付余额
	var option3 = {
		"grid": {
			"top": "15%",
			"left": "5%",
			"right": "5%",
			"bottom": "5%",
			"containLabel": true
		},
		"xAxis": {
			"type": "category",
			"data": ["1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月"],
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			},
			axisLabel: {
				interval: 0,
				margin: 10,
				textStyle: {
					color: "#84878e"
				}
			}
		},
		"yAxis": [{
			"type": "value",
			"name": "亿元",
			"position": "left",
			"splitNumber": 5,
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		}],
		"series": [{
			"name": "收入",
			"type": "bar",
			"data": [726.2, 726.2, 726.2, 746.2, 746.2, 746.2, 746.2, 746.2, 746.2, 746.2, 746.2, 746.2],
			"barWidth": 8,
			"itemStyle": {
				"normal": {
					"color": "#f3374b"
				}
			},
			"barGap": "30%",
			label: {
				show: true,
				position: 'top',
				fontSize: window.FONTSIZE * 0.18
			}
		}],
		"tooltip": {
			"show": true,
			"trigger": "axis"
		}
	}
	var echartsContainer = echarts.init($("#chart3").get(0));
	echartsContainer.setOption(option3);
});