$(document).ready(function() {

	$(".search input").on("keyup", function() {
		if ($(this).val().trim() == "") {
			$(".search_result").addClass("op_0");
		} else {
			$(".search_result").removeClass("op_0");
		}
	});

	$(".search_result .item").on("click", function() {
		$(".search_result").addClass("op_0");
		$(".search input").val($(this).text());
	});

	var option1 = {
		"legend": {
			"show": false
		},
		"grid": {},
		"title": {
			"textStyle": {
				"color": "#f3374b",
				"fontSize": window.FONTSIZE * 0.4, //在设计图上改字体是40px，750px的宽度比例
				"fontWeight": "normal"
			},
			"subtextStyle": {
				"color": "#84878e",
				"fontSize": window.FONTSIZE * 0.24, //在设计图上改字体是24px，750px的宽度比例
				"fontWeight": "normal"
			},
			"x": "center",
			"y": "40%",
			"text": "60.6%",
			"subtext": "实体占比"
		},
		"calculable": true,
		"series": [{
			"name": "总量",
			"type": "pie",
			"z": 0,
			"center": ["50%", "50%"],
			"radius": ["65%", "80%"],
			"data": [{
				"value": 1368.25,
				"name": "年度累计",
				"itemStyle": {
					"normal": {
						"color": "#f39800"
					}
				},
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": true,
				"stack": "各业态月收入"
			}, {
				"value": 2368,
				"name": "年度预算",
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#2FB4FC"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart1").get(0));
	echartsContainer.setOption(option1);

	var option2 = {
		"legend": {
			"show": false
		},
		"grid": {},
		"title": {
			"textStyle": {
				"color": "#84878e",
				"fontSize": window.FONTSIZE * 0.28, //在设计图上改字体是40px，750px的宽度比例
				"fontWeight": "normal"
			},
			"subtextStyle": {
				"color": "#84878e",
				"fontSize": window.FONTSIZE * 0.28, //在设计图上改字体是24px，750px的宽度比例
				"fontWeight": "normal"
			},
			"x": "center",
			"y": "42%",
			"text": "境内:45.34%",
			"subtext": "境外:45.68%"
		},
		"calculable": true,
		"series": [{
			"name": "总量",
			"type": "pie",
			"z": 0,
			"center": ["50%", "50%"],
			"radius": ["65%", "80%"],
			"data": [{
				"value": 1368.25,
				"name": "年度累计",
				"itemStyle": {
					"normal": {
						"color": "#f39800"
					}
				},
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": true,
				"stack": "各业态月收入"
			}, {
				"value": 2368,
				"name": "年度预算",
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#20BCFA"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart2").get(0));
	echartsContainer.setOption(option2);

	var option3 = {
		"legend": {
			"show": false
		},
		"grid": {},
		"title": {
			"textStyle": {
				"color": "#f3374b",
				"fontSize": window.FONTSIZE * 0.4, //在设计图上改字体是40px，750px的宽度比例
				"fontWeight": "normal"
			},
			"subtextStyle": {
				"color": "#84878e",
				"fontSize": window.FONTSIZE * 0.24, //在设计图上改字体是24px，750px的宽度比例
				"fontWeight": "normal"
			},
			"x": "center",
			"y": "40%",
			"text": "60.6%",
			"subtext": "上市占比"
		},
		"calculable": true,
		"series": [{
			"name": "总量",
			"type": "pie",
			"z": 0,
			"center": ["50%", "50%"],
			"radius": ["65%", "80%"],
			"data": [{
				"value": 1368.25,
				"name": "年度累计",
				"itemStyle": {
					"normal": {
						"color": "#f39800"
					}
				},
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": true,
				"stack": "各业态月收入"
			}, {
				"value": 2368,
				"name": "年度预算",
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#2FB4FC"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart3").get(0));
	echartsContainer.setOption(option3);

});