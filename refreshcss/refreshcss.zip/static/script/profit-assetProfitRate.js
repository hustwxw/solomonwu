// 第一行可滑动关联指标
var swiper = new Swiper('.relative_index', {
	slidesPerView: 2.2,
	spaceBetween: 15,
	freeMode: true
});

$(document).ready(function() {

	//echarts渲染
	// 目标达成情况
	var option1 = {
		tooltip: {
			formatter: "{a} <br/>{b} : {c}%"
		},
		toolbox: {
			show: false,
			feature: {
				mark: {
					show: true
				},
				restore: {
					show: true
				},
				saveAsImage: {
					show: true
				}
			}
		},
		series: [{
			name: '完成率',
			type: 'gauge',
			center: ["50%", "50%"],
			radius: "90%",
			splitNumber: 10, // 分割段数，默认为5
			axisLine: { // 坐标轴线
				lineStyle: { // 属性lineStyle控制线条样式
					color: [
						[0.2, '#08c61e'],
						[0.7, '#fcdc08'],
						[1, '#ff5454']
					],
					width: 5
				}
			},
			axisTick: { // 坐标轴小标记
				splitNumber: 10, // 每份split细分多少段
				length: 0, // 属性length控制线长
				lineStyle: { // 属性lineStyle控制线条样式
					color: 'auto'
				}
			},
			axisLabel: { // 坐标轴文本标签，详见axis.axisLabel
				textStyle: { // 其余属性默认使用全局文本样式，详见TEXTSTYLE
					color: 'auto'
				}
			},
			splitLine: { // 分隔线
				show: true, // 默认显示，属性show控制显示与否
				length: 14, // 属性length控制线长
				lineStyle: { // 属性lineStyle（详见lineStyle）控制线条样式
					color: 'auto'
				}
			},
			pointer: {
				width: 4,
				length: '60%'
			},
			title: {
				show: true,
				// y:"bottom",
				offsetCenter: [0, '100%'], // x, y，单位px
				textStyle: { // 其余属性默认使用全局文本样式，详见TEXTSTYLE
					color: '#b5c9fa',
					fontSize: 18,

				},
			},
			detail: {
				formatter: '{value}%',
				textStyle: { // 其余属性默认使用全局文本样式，详见TEXTSTYLE
					color: 'auto',
					fontSize: 18,
				},
				offsetCenter: [0, '55%']
			},
			data: [{
				value: 49,
				name: '海航集团'
			}]
		}]
	};

	var echartsContainer = echarts.init($("#chart1").get(0));
	echartsContainer.setOption(option1);

	// 产业集团
	function getOption(i) {
		return {
			tooltip: {
				formatter: "{a} <br/>{b} : {c}%"
			},
			toolbox: {
				show: false,
				feature: {
					mark: {
						show: true
					},
					restore: {
						show: true
					},
					saveAsImage: {
						show: true
					}
				}
			},
			series: [{
				name: '完成率',
				type: 'gauge',
				center: ["50%", "50%"],
				radius: "80%",
				splitNumber: 10, // 分割段数，默认为5
				axisLine: { // 坐标轴线
					lineStyle: { // 属性lineStyle控制线条样式
						color: [
							[0.2, '#08c61e'],
							[0.7, '#fcdc08'],
							[1, '#ff5454']
						],
						width: 5
					}
				},
				axisTick: { // 坐标轴小标记
					splitNumber: 10, // 每份split细分多少段
					length: 0, // 属性length控制线长
					lineStyle: { // 属性lineStyle控制线条样式
						color: 'auto'
					}
				},
				axisLabel: { // 坐标轴文本标签，详见axis.axisLabel
					textStyle: { // 其余属性默认使用全局文本样式，详见TEXTSTYLE
						color: 'auto',
						fontSize: 7
					}
				},
				splitLine: { // 分隔线
					show: true, // 默认显示，属性show控制显示与否
					length: 10, // 属性length控制线长
					lineStyle: { // 属性lineStyle（详见lineStyle）控制线条样式
						color: 'auto'
					}
				},
				pointer: {
					width: 4,
					length: '60%'
				},
				title: {
					show: true,
					// y:"bottom",
					offsetCenter: [0, '100%'], // x, y，单位px
					textStyle: { // 其余属性默认使用全局文本样式，详见TEXTSTYLE
						color: '#b5c9fa',
						fontSize: 12,

					},
				},
				detail: {
					formatter: '{value}%',
					textStyle: { // 其余属性默认使用全局文本样式，详见TEXTSTYLE
						color: 'auto',
						fontSize: 12,
					},
					offsetCenter: [0, '55%']
				},
				data: [{
					value: [10, 80, 50, 70, 90, 70, 90][i],
					name: ["海航科技", "海航现代物流", "海航实业", "海航资本", "海航新媒体", "海航创新金融", "海航xx"][i]
				}]
			}]
		};
	}

	$(".item").each(function(i, ele) {
		var echartsContainer = echarts.init(ele);
		echartsContainer.setOption(getOption(i));
	});

});