// window.FONTSIZE是定义域html根元素上的适配转换比例，定义在lib.js里面

// 关联指标滑动
var swiper = new Swiper('#relative', {
	slidesPerView: 2.2,
	spaceBetween: 15,
	freeMode: true
});

$(document).ready(function() {

	// echart渲染

	// 当月收入
	var option1 = {
		"legend": {
			"show": false
		},
		"grid": {},
		"title": {
			"textStyle": {
				"color": "#f3374b",
				"fontSize": window.FONTSIZE * 0.4, //在设计图上改字体是40px，750px的宽度比例
				"fontWeight": "normal"
			},
			"subtextStyle": {
				"color": "#84878e",
				"fontSize": window.FONTSIZE * 0.24, //在设计图上改字体是24px，750px的宽度比例
				"fontWeight": "normal"
			},
			"x": "center",
			"y": "35%",
			"text": "60.6%",
			"subtext": "完成当月预算"
		},
		"calculable": true,
		"series": [{
			"name": "总量",
			"type": "pie",
			"z": 0,
			"center": ["50%", "50%"],
			"radius": ["80%", "100%"],
			"data": [{
				"value": 1368.25,
				"name": "年度累计",
				"itemStyle": {
					"normal": {
						"color": "#f3374b"
					}
				},
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": true,
				"stack": "各业态月收入"
			}, {
				"value": 2368,
				"name": "年度预算",
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#f5f5f5"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart1").get(0));
	echartsContainer.setOption(option1);

	// 年度收入
	var option2 = {
		"legend": {
			"show": false
		},
		"grid": {},
		"title": {
			"textStyle": {
				"color": "#f3374b",
				"fontSize": window.FONTSIZE * 0.4, //在设计图上改字体是40px，750px的宽度比例
				"fontWeight": "normal"
			},
			"subtextStyle": {
				"color": "#84878e",
				"fontSize": window.FONTSIZE * 0.24, //在设计图上改字体是24px，750px的宽度比例
				"fontWeight": "normal"
			},
			"x": "center",
			"y": "35%",
			"text": "60.6%",
			"subtext": "完成年度预算"
		},
		"calculable": true,
		"series": [{
			"name": "总量",
			"type": "pie",
			"z": 0,
			"center": ["50%", "50%"],
			"radius": ["65%", "80%"],
			"data": [{
				"value": 1368.25,
				"name": "年度累计",
				"itemStyle": {
					"normal": {
						"color": "#f39800"
					}
				},
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": true,
				"stack": "各业态月收入"
			}, {
				"value": 2368,
				"name": "年度预算",
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#f5f5f5"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart2").get(0));
	echartsContainer.setOption(option2);

	// 重点企业
	var option3 = {
		"legend": {
			"data": ["收入", "贡献值"]
		},
		"grid": {
			"top": "15%",
			"left": "5%",
			"right": "5%",
			"bottom": "2%",
			"containLabel": true
		},
		"xAxis": {
			"type": "category",
			"data": ["海航科技", "海航航旅", "海航资本", "海航现代物流", "海航实业", "海航新传媒", "海航创新金融"],
			axisLabel: {
				interval: 0,
				rotate: 45,
				margin: 10,
				textStyle: {
					color: "#84878e"
				}
			},
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		},
		"yAxis": [{
			"type": "value",
			"name": "亿元",
			"position": "left",
			"splitNumber": 5,
			"axisLabel": {
				"textStyle": {
					color: "#84878e"
				}
			},
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		}, {
			"type": "value",
			"name": "%",
			"position": "right",
			"splitNumber": 5,
			"splitLine": {
				"show": false
			},
			"axisLabel": {
				"textStyle": {
					color: "#84878e"
				}
			},
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		}],
		"series": [{
			"name": "收入",
			"type": "bar",
			"data": [100, 200, 300, 400, 500, 600, 700],
			"barWidth": 12,
		}, {
			"name": "贡献值",
			"type": "line",
			"showSymbol": true,
			// "smooth": true,
			"symbolSize": 10,
			"symbol": "emptyCircle",
			"yAxisIndex": 1,
			"itemStyle": {
				"normal": {
					"color": "#f39800"
				}
			},
			"data": [0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8]
		}],
		"tooltip": {
			"show": true,
			"trigger": "axis"
		}
	}
	var echartsContainer = echarts.init($("#chart3").get(0));
	echartsContainer.setOption(option3);

	// 时间
	var option4 = {
		"legend": {
			"data": ["收入", "预算"]
		},
		"grid": {
			"top": "15%",
			"left": "5%",
			"right": "5%",
			"bottom": "5%",
			"containLabel": true
		},
		"xAxis": {
			"type": "category",
			"data": ["1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月"],
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			},
			axisLabel: {
				interval: 0,
				margin: 10,
				textStyle: {
					color: "#84878e"
				}
			}
		},
		"yAxis": [{
			"type": "value",
			"name": "亿元",
			"position": "left",
			"splitNumber": 5,
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		}],
		"series": [{
			"name": "收入",
			"type": "bar",
			"data": [726.2, 726.2, 726.2, 746.2, 746.2, 746.2, 746.2, 746.2, 746.2, 746.2, 746.2, 746.2],
			"barWidth": 8,
			"itemStyle": {
				"normal": {
					"color": "#f3374b"
				}
			},
			"barGap": "30%"
		}, {
			"name": "预算",
			"type": "bar",
			"data": [204.12, 204.12, 236.14, 245.2, 245.2, 245.2, 616.2, 616.2, 616.2, 616.2, 616.2, 726.2],
			"barWidth": 8,
			"itemStyle": {
				"normal": {
					"color": "#f39800"
				}
			},
			"barGap": "30%"
		}],
		"tooltip": {
			"show": true,
			"trigger": "axis"
		}
	}
	var echartsContainer = echarts.init($("#chart4").get(0));
	echartsContainer.setOption(option4);

	// 境内境外
	var option5 = {
		"legend": {
			"show": false
		},
		"grid": {},
		"title": {
			"textStyle": {
				"color": "#f3374b",
				"fontSize": window.FONTSIZE * 0.4, //在设计图上改字体是40px，750px的宽度比例
				"fontWeight": "normal"
			},
			"subtextStyle": {
				"color": "#84878e",
				"fontSize": window.FONTSIZE * 0.24, //在设计图上改字体是24px，750px的宽度比例
				"fontWeight": "normal"
			},
			"x": "center",
			"y": "38%",
			"text": "61.6%",
			"subtext": "境内"
		},
		"calculable": true,
		"series": [{
			"name": "总量",
			"type": "pie",
			"z": 0,
			"center": ["50%", "50%"],
			"radius": ["70%", "85%"],
			"data": [{
				"value": 1368.25,
				"name": "年度累计",
				"itemStyle": {
					"normal": {
						"color": "#f3374b"
					}
				},
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": true,
				"stack": "各业态月收入"
			}, {
				"value": 2368,
				"name": "年度预算",
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#f39800"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart5").get(0));
	echartsContainer.setOption(option5);

});