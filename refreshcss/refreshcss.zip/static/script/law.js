$(document).ready(function() {

	// 产业集团
	var option1 = {
		"legend": {
			"data": ["案件总计", "新增案件数量", "办结案件数量", "涉及金额", "新增涉及金额", "办结涉及金额"]
		},
		"grid": {
			"top": "30%",
			"left": "10%",
			"right": "10%",
			"bottom": "2%",
			"containLabel": true
		},
		"xAxis": {
			"type": "category",
			"data": ["海航科技", "海航航旅", "海航资本", "海航现代物流", "海航实业", "海航新传媒", "海航创新金融"],
			axisLabel: {
				interval: 0,
				rotate: 30,
				margin: 10,
				textStyle: {
					color: "#84878e"
				}
			},
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		},
		"yAxis": [{
			"type": "value",
			"name": "个",
			"position": "left",
			"splitNumber": 5,
			"axisLabel": {
				"textStyle": {
					color: "#84878e"
				}
			},
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		}, {
			"type": "value",
			"name": "亿元",
			"position": "right",
			"splitNumber": 5,
			"splitLine": {
				"show": false
			},
			"axisLabel": {
				"textStyle": {
					color: "#84878e"
				}
			},
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		}],
		"series": [{
			"name": "案件总计",
			"type": "bar",
			"data": [100, 200, 300, 400, 500, 600, 700],
			"barWidth": 5,
			"barGap": 1,
			"itemStyle": {
				"normal": {
					"color": "#f3374b"
				}
			}
		}, {
			"name": "新增案件数量",
			"type": "bar",
			"data": [100, 200, 300, 400, 500, 600, 700],
			"barWidth": 5,
			"barGap": 1,
			"itemStyle": {
				"normal": {
					"color": "#00b7ee"
				}
			}
		}, {
			"name": "办结案件数量",
			"type": "bar",
			"data": [100, 200, 300, 400, 500, 600, 700],
			"barWidth": 5,
			"barGap": 1,
			"itemStyle": {
				"normal": {
					"color": "#f19149"
				}
			}
		}, {
			"name": "涉及金额",
			"type": "line",
			"showSymbol": true,
			// "smooth": true,
			"symbolSize": 10,
			"symbol": "emptyCircle",
			"yAxisIndex": 1,
			"itemStyle": {
				"normal": {
					"color": "#f39800"
				}
			},
			"data": [30, 40, 50, 60, 70, 80, 90]
		}, {
			"name": "新增涉及金额",
			"type": "line",
			"showSymbol": true,
			"symbolSize": 10,
			"symbol": "emptyCircle",
			"yAxisIndex": 1,
			"itemStyle": {
				"normal": {
					"color": "#ea68a2"
				}
			},
			"data": [20, 30, 40, 50, 60, 70, 80]
		}, {
			"name": "办结涉及金额",
			"type": "line",
			"showSymbol": true,
			"symbolSize": 10,
			"symbol": "emptyCircle",
			"yAxisIndex": 1,
			"itemStyle": {
				"normal": {
					"color": "#ae5da1"
				}
			},
			"data": [10, 20, 30, 40, 50, 60, 70]
		}],
		"tooltip": {
			"show": true,
			"trigger": "axis"
		}
	}
	var echartsContainer = echarts.init($("#chart1").get(0));
	echartsContainer.setOption(option1);

	// 时间
	var option2 = {
		"legend": {
			"data": ["案件总计", "新增案件数量", "办结案件数量", "涉及金额", "新增涉及金额", "办结涉及金额"]
		},
		"grid": {
			"top": "30%",
			"left": "10%",
			"right": "10%",
			"bottom": "2%",
			"containLabel": true
		},
		"xAxis": {
			"type": "category",
			"data": ["2018/01/26", "2018/02/03", "2018/2/10", "2018/2/17"],
			axisLabel: {
				interval: 0,
				rotate: 20,
				margin: 10,
				textStyle: {
					color: "#84878e",
					fontSize: window.FONTSIZE * 0.2
				}
			},
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		},
		"yAxis": [{
			"type": "value",
			"name": "个",
			"position": "left",
			"splitNumber": 5,
			"axisLabel": {
				"textStyle": {
					color: "#84878e"
				}
			},
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		}, {
			"type": "value",
			"name": "亿元",
			"position": "right",
			"splitNumber": 5,
			"splitLine": {
				"show": false
			},
			"axisLabel": {
				"textStyle": {
					color: "#84878e"
				}
			},
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		}],
		"series": [{
			"name": "案件总计",
			"type": "bar",
			"data": [100, 200, 300, 400],
			"barWidth": 5,
			"barGap": 1,
			"itemStyle": {
				"normal": {
					"color": "#f3374b"
				}
			}
		}, {
			"name": "新增案件数量",
			"type": "bar",
			"data": [100, 200, 300, 400],
			"barWidth": 5,
			"barGap": 1,
			"itemStyle": {
				"normal": {
					"color": "#00b7ee"
				}
			}
		}, {
			"name": "办结案件数量",
			"type": "bar",
			"data": [100, 200, 300, 400],
			"barWidth": 5,
			"barGap": 1,
			"itemStyle": {
				"normal": {
					"color": "#f19149"
				}
			}
		}, {
			"name": "涉及金额",
			"type": "line",
			"showSymbol": true,
			// "smooth": true,
			"symbolSize": 10,
			"symbol": "emptyCircle",
			"yAxisIndex": 1,
			"itemStyle": {
				"normal": {
					"color": "#f39800"
				}
			},
			"data": [30, 40, 50, 60]
		}, {
			"name": "新增涉及金额",
			"type": "line",
			"showSymbol": true,
			"symbolSize": 10,
			"symbol": "emptyCircle",
			"yAxisIndex": 1,
			"itemStyle": {
				"normal": {
					"color": "#ea68a2"
				}
			},
			"data": [20, 30, 40, 50]
		}, {
			"name": "办结涉及金额",
			"type": "line",
			"showSymbol": true,
			"symbolSize": 10,
			"symbol": "emptyCircle",
			"yAxisIndex": 1,
			"itemStyle": {
				"normal": {
					"color": "#ae5da1"
				}
			},
			"data": [10, 50, 60, 70]
		}],
		"tooltip": {
			"show": true,
			"trigger": "axis"
		}
	}
	var echartsContainer = echarts.init($("#chart2").get(0));
	echartsContainer.setOption(option2);

	// 在办案件类型
	var option3 = {
		"legend": {
			"data": ["案件总计", "涉及金额"]
		},
		"grid": {
			"top": "30%",
			"left": "10%",
			"right": "10%",
			"bottom": "2%",
			"containLabel": true
		},
		"xAxis": {
			"type": "category",
			"data": ["合同纠纷", "劳动争议纠纷", "侵权纠纷", "其他纠纷"],
			axisLabel: {
				interval: 0,
				rotate: 0,
				margin: 10,
				textStyle: {
					color: "#84878e",
					fontSize: window.FONTSIZE * 0.2
				}
			},
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		},
		"yAxis": [{
			"type": "value",
			"name": "个",
			"position": "left",
			"splitNumber": 5,
			"axisLabel": {
				"textStyle": {
					color: "#84878e"
				}
			},
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		}, {
			"type": "value",
			"name": "亿元",
			"position": "right",
			"splitNumber": 5,
			"splitLine": {
				"show": false
			},
			"axisLabel": {
				"textStyle": {
					color: "#84878e"
				}
			},
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		}],
		"series": [{
			"name": "案件总计",
			"type": "bar",
			"data": [100, 200, 300, 400],
			"barWidth": 10,
			"barGap": 1,
			"itemStyle": {
				"normal": {
					"color": "#f3374b"
				}
			}
		}, {
			"name": "涉及金额",
			"type": "line",
			"showSymbol": true,
			// "smooth": true,
			"symbolSize": 10,
			"symbol": "emptyCircle",
			"yAxisIndex": 1,
			"itemStyle": {
				"normal": {
					"color": "#f39800"
				}
			},
			"data": [50, 60, 60, 29]
		}],
		"tooltip": {
			"show": true,
			"trigger": "axis"
		}
	}
	var echartsContainer = echarts.init($("#chart3").get(0));
	echartsContainer.setOption(option3);

	// 在办案件性质
	var option4 = {
		"legend": {
			"data": ["案件总计", "涉及金额"]
		},
		"grid": {
			"top": "30%",
			"left": "10%",
			"right": "10%",
			"bottom": "2%",
			"containLabel": true
		},
		"xAxis": {
			"type": "category",
			"data": ["重大民事", "一般民事", "刑事"],
			axisLabel: {
				interval: 0,
				rotate: 0,
				margin: 10,
				textStyle: {
					color: "#84878e",
					fontSize: window.FONTSIZE * 0.2
				}
			},
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		},
		"yAxis": [{
			"type": "value",
			"name": "个",
			"position": "left",
			"splitNumber": 5,
			"axisLabel": {
				"textStyle": {
					color: "#84878e"
				}
			},
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		}, {
			"type": "value",
			"name": "亿元",
			"position": "right",
			"splitNumber": 5,
			"splitLine": {
				"show": false
			},
			"axisLabel": {
				"textStyle": {
					color: "#84878e"
				}
			},
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		}],
		"series": [{
			"name": "案件总计",
			"type": "bar",
			"data": [100, 200, 400],
			"barWidth": 10,
			"barGap": 1,
			"itemStyle": {
				"normal": {
					"color": "#f3374b"
				}
			}
		}, {
			"name": "涉及金额",
			"type": "line",
			"showSymbol": true,
			// "smooth": true,
			"symbolSize": 10,
			"symbol": "emptyCircle",
			"yAxisIndex": 1,
			"itemStyle": {
				"normal": {
					"color": "#f39800"
				}
			},
			"data": [50, 60, 29]
		}],
		"tooltip": {
			"show": true,
			"trigger": "axis"
		}
	}
	var echartsContainer = echarts.init($("#chart4").get(0));
	echartsContainer.setOption(option4);

	// 案件状态
	var option5 = {
		"legend": {
			"data": ["案件总计", "涉及金额"]
		},
		"grid": {
			"top": "30%",
			"left": "10%",
			"right": "10%",
			"bottom": "2%",
			"containLabel": true
		},
		"xAxis": {
			"type": "category",
			"data": ["在办案件", "执行案件", "办结案件"],
			axisLabel: {
				interval: 0,
				rotate: 0,
				margin: 10,
				textStyle: {
					color: "#84878e",
					fontSize: window.FONTSIZE * 0.2
				}
			},
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		},
		"yAxis": [{
			"type": "value",
			"name": "个",
			"position": "left",
			"splitNumber": 5,
			"axisLabel": {
				"textStyle": {
					color: "#84878e"
				}
			},
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		}, {
			"type": "value",
			"name": "亿元",
			"position": "right",
			"splitNumber": 5,
			"splitLine": {
				"show": false
			},
			"axisLabel": {
				"textStyle": {
					color: "#84878e"
				}
			},
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		}],
		"series": [{
			"name": "案件总计",
			"type": "bar",
			"data": [100, 200, 400],
			"barWidth": 10,
			"barGap": 1,
			"itemStyle": {
				"normal": {
					"color": "#f3374b"
				}
			}
		}, {
			"name": "涉及金额",
			"type": "line",
			"showSymbol": true,
			// "smooth": true,
			"symbolSize": 10,
			"symbol": "emptyCircle",
			"yAxisIndex": 1,
			"itemStyle": {
				"normal": {
					"color": "#f39800"
				}
			},
			"data": [50, 60, 29]
		}],
		"tooltip": {
			"show": true,
			"trigger": "axis"
		}
	}
	var echartsContainer = echarts.init($("#chart5").get(0));
	echartsContainer.setOption(option5);

	// 案件数量
	var option6 = {
		"legend": {
			"show": false
		},
		"grid": {},
		"title": {
			"textStyle": {
				"color": "#f3374b",
				"fontSize": window.FONTSIZE * 0.4, //在设计图上改字体是40px，750px的宽度比例
				"fontWeight": "normal"
			},
			"x": "center",
			"y": "center",
			"text": "案件数量"
		},
		"calculable": true,
		"series": [{
			"name": "总量",
			"type": "pie",
			"z": 0,
			"center": ["50%", "50%"],
			"radius": ["80%", "100%"],
			"data": [{
				"value": 1368.25,
				"name": "年度累计",
				"itemStyle": {
					"normal": {
						"color": "#f3374b"
					}
				},
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": true,
				"stack": "各业态月收入"
			}, {
				"value": 2368,
				"name": "年度预算",
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#f39800"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart6").get(0));
	echartsContainer.setOption(option6);

	// 涉及金额
	var option7 = {
		"legend": {
			"show": false
		},
		"grid": {},
		"title": {
			"textStyle": {
				"color": "#f3374b",
				"fontSize": window.FONTSIZE * 0.4, //在设计图上改字体是40px，750px的宽度比例
				"fontWeight": "normal"
			},
			"x": "center",
			"y": "center",
			"text": "涉及金额"
		},
		"calculable": true,
		"series": [{
			"name": "总量",
			"type": "pie",
			"z": 0,
			"center": ["50%", "50%"],
			"radius": ["80%", "100%"],
			"data": [{
				"value": 1368.25,
				"name": "年度累计",
				"itemStyle": {
					"normal": {
						"color": "#00b7ee"
					}
				},
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": true,
				"stack": "各业态月收入"
			}, {
				"value": 2368,
				"name": "年度预算",
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": true,
				"stack": "各业态月收入",
				"itemStyle": {
					"normal": {
						"color": "#f39800"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart7").get(0));
	echartsContainer.setOption(option7);

});