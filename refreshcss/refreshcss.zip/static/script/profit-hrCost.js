// 第一行可滑动关联指标
var swiper = new Swiper('.relative_index', {
	slidesPerView: 2.2,
	spaceBetween: 15,
	freeMode: true
});

$(document).ready(function() {

	//echarts渲染

	// 时间线图
	// 时间
	var option = {
		legend: {
			show: true,
			right: '0%',
			top: '0%',
			itemWidth: window.FONTSIZE * 0.3,
			itemHeight: window.FONTSIZE * 0.15,
			textStyle: {
				fontSize: window.FONTSIZE * 0.16,
				color: '#333'
			}
		},
		"grid": {
			"top": "15%",
			"left": "5%",
			"right": "5%",
			"bottom": "5%",
			"containLabel": true
		},
		"xAxis": {
			"type": "category",
			"data": ["1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月"],
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			},
			axisLabel: {
				interval: 0,
				margin: 10,
				textStyle: {
					color: "#84878e"
				}
			}
		},
		"yAxis": [{
			"type": "value",
			"name": "亿元",
			"position": "left",
			"splitNumber": 5,
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		}],
		"series": [{
			"name": "2017",
			"type": "bar",
			"data": [726.2, 726.2, 726.2, 746.2, 746.2, 746.2, 746.2, 746.2, 746.2, 746.2, 746.2, 746.2],
			"barWidth": 8,
			"itemStyle": {
				"normal": {
					"color": "#f3374b"
				}
			},
			"barGap": "30%",
			label: {
				show: true,
				position: "top",
				fontSize: window.FONTSIZE * 0.14
			}
		}, {
			"name": "2018",
			"type": "bar",
			"data": [204.12, 204.12, 236.14, 245.2, 245.2, 245.2, 616.2, 616.2, 616.2, 616.2, 616.2, 726.2],
			"barWidth": 8,
			"itemStyle": {
				"normal": {
					"color": "#f39800"
				}
			},
			label: {
				show: true,
				position: "top",
				fontSize: window.FONTSIZE * 0.14
			},
			"barGap": "30%"
		}],
		"tooltip": {
			"show": true,
			"trigger": "axis"
		}
	}
	var echartsContainer = echarts.init($("#chart").get(0));
	echartsContainer.setOption(option);

});