// 第一行可滑动关联指标
var swiper = new Swiper('.relative_index', {
	slidesPerView: 2.2,
	spaceBetween: 15,
	freeMode: true
});

$(document).ready(function() {

	//echarts渲染

	// 产业集团
	var option1 = {
		backgroundColor: '#ffffff',
		legend: {
			show: false
		},
		grid: {
			left: '1%',
			right: '12%',
			bottom: '10%',
			top: '6%',
			containLabel: true
		},

		tooltip: {
			show: "true",
			trigger: 'axis',
			axisPointer: { // 坐标轴指示器，坐标轴触发有效
				type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
			}
		},
		xAxis: {
			type: 'value',
			axisTick: {
				show: false
			},
			axisLine: {
				show: true,
				lineStyle: {
					color: '#84878e',
				}
			},
			splitLine: {
				show: true
			},
			name: '亿元'
		},
		yAxis: [{
				type: 'category',
				axisLine: {
					show: false
				},
				axisTick: {
					show: false
				},
				axisLabel: {
					show: true
				},
				splitArea: {
					show: false
				},
				splitLine: {
					show: false
				},
				data: ['海航资本', '海航实业', '海航现代物流', '海航科技', '海航创新金融', '海航新传媒'].reverse()
			},

		],
		series: [{
				name: '资产总额',
				type: 'bar',

				itemStyle: {
					normal: {
						show: true,
						color: '#f3374b',
						borderWidth: 0
					}
				},
				barGap: '0%',
				barCategoryGap: '50%',
				data: [120, 132, 101, 134, 90, 230]
			}

		]
	};

	var echartsContainer = echarts.init($("#chart1").get(0));
	echartsContainer.setOption(option1);

	// 时间线图
	var option2 = {
		"legend": {
			"data": ["2017", "2018", "2018全年目标"]
		},
		"grid": {
			"top": "15%",
			"left": "5%",
			"right": "5%",
			"bottom": "2%",
			"containLabel": true
		},
		"xAxis": {
			"type": "category",
			"data": ["1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月"],
			axisLabel: {
				interval: 0,
				rotate: 0,
				margin: 10,
				textStyle: {
					color: "#84878e"
				}
			},
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		},
		"yAxis": {
			"type": "value",
			"name": "%",
			"position": "left",
			"splitNumber": 5,
			"splitLine": {
				"show": true
			},
			"axisLabel": {
				"textStyle": {
					color: "#84878e"
				}
			},
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		},
		"series": [{
			"name": "2017",
			"type": "line",
			"showSymbol": true,
			"smooth": true,
			"symbolSize": 5,
			"symbol": "emptyCircle",
			"itemStyle": {
				"normal": {
					"color": "#C8E0F0"
				}
			},
			label: {
				show: true
			},
			"data": [0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.22, 0.33, 0.54, 0.1, 0.5]
		}, {
			"name": "2018",
			"type": "line",
			"showSymbol": true,
			"smooth": true,
			"symbolSize": 5,
			"symbol": "emptyCircle",
			"itemStyle": {
				"normal": {
					"color": "#f3374b"
				}
			},
			label: {
				show: true
			},
			"data": [0.2, 0.5, 0.34, 0.15, 0.96, 0.27, 0.28, 0.34, 0.54, 0.98, 0.03, 0.29, 0.22, 0.99]
		}],
		"tooltip": {
			"show": true,
			"trigger": "axis"
		}
	}
	var echartsContainer = echarts.init($("#chart2").get(0));
	echartsContainer.setOption(option2);

});