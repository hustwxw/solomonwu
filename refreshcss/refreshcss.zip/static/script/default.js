$(document).ready(function() {

	// 收入
	var option1 = {
		"legend": {
			"show": false
		},
		"grid": {},
		"title": {
			"textStyle": {
				"color": "#f3374b",
				"fontSize": window.FONTSIZE * 0.30, //在设计图上改字体是40px，750px的宽度比例
				"fontWeight": "normal"
			},
			"subtextStyle": {
				"rich": {
					"a": {
						"color": "#84878e",
						"fontSize": window.FONTSIZE * 0.18,
						"fontWeight": "normal",
						"lineHeight": 10
					},
					"b": {
						"color": "#84878e",
						"fontSize": window.FONTSIZE * 0.18,
						"fontWeight": "normal",
						"lineHeight": 10
					}
				}
			},
			"x": "center",
			"x": "center",
			"y": "35%",
			"text": "48.15%",
			"subtext": "{a|完成当月}\n{b|预算}",
			"itemGap": 2,
			"padding": [0, 5]
		},
		"calculable": true,
		"series": [{
			"name": "总量",
			"type": "pie",
			"z": 0,
			"center": ["50%", "50%"],
			"radius": ["70%", "90%"],
			"data": [{
				"value": 3,
				"name": "年度累计",
				"itemStyle": {
					"normal": {
						"color": "#f5f5f5"
					}
				},
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": false
			}, {
				"value": 2,
				"name": "年度预算",
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": false,
				"itemStyle": {
					"normal": {
						"color": "#f3374b"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart1").get(0));
	echartsContainer.setOption(option1);

	// 利润
	var option2 = {
		"legend": {
			"show": false
		},
		"grid": {},
		"title": {
			"textStyle": {
				"color": "#f3374b",
				"fontSize": window.FONTSIZE * 0.30, //在设计图上改字体是40px，750px的宽度比例
				"fontWeight": "normal"
			},
			"subtextStyle": {
				"rich": {
					"a": {
						"color": "#84878e",
						"fontSize": window.FONTSIZE * 0.18,
						"fontWeight": "normal",
						"lineHeight": 10
					},
					"b": {
						"color": "#84878e",
						"fontSize": window.FONTSIZE * 0.18,
						"fontWeight": "normal",
						"lineHeight": 10
					}
				}
			},
			"x": "center",
			"x": "center",
			"y": "35%",
			"text": "48.15%",
			"subtext": "{a|完成当月}\n{b|预算}",
			"itemGap": 2,
			"padding": [0, 5]
		},
		"calculable": true,
		"series": [{
			"name": "总量",
			"type": "pie",
			"z": 0,
			"center": ["50%", "50%"],
			"radius": ["70%", "90%"],
			"data": [{
				"value": 3,
				"name": "年度累计",
				"itemStyle": {
					"normal": {
						"color": "#f5f5f5"
					}
				},
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": false
			}, {
				"value": 2,
				"name": "年度预算",
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": false,
				"itemStyle": {
					"normal": {
						"color": "#f3374b"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart2").get(0));
	echartsContainer.setOption(option2);

	// 头寸
	var option3 = {
		"legend": {
			show: false
		},
		"grid": {
			"right": "5%"
		},
		"backgroundColor": "#fff",
		"tooltip": {
			"formatter": "{a} <br/>{b} : {c}%"
		},
		"series": [{
			"type": "pie",
			"z": 0,
			"center": ["50%", "50%"],
			"radius": ["70%", "73%"],
			"startAngle": 315,
			"data": [{
				"value": 1,
				"itemStyle": {
					"normal": {
						"color": "#fff"
					}
				},
				"z": 1,
				"tooltip": {
					"show": false
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": false
			}, {
				"value": 3,
				"z": 0,
				"itemStyle": {
					"normal": {
						"color": "#ddd"
					}
				},
				"tooltip": {
					"show": false
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": false
			}]
		}, {
			"name": "头寸",
			"radius": "90%",
			"type": "gauge",
			"min": 0,
			"max": 3000,
			"z": 100,
			"splitNumber": 3,
			"axisLine": {
				"lineStyle": {
					"color": [
						[0.33, "#33cc34"],
						[0.67, "#00b7ee"],
						[1, "#f11d1b"]
					],
					"width": "5"
				}
			},
			"axisTick": {
				"lineStyle": {
					"color": "#fff",
					"width": 3
				},
				"length": 50,
				"splitNumber": 1
			},
			"axisLabel": {
				"distance": -52,
				"textStyle": {
					"color": "#9c9c9c",
					"fontSize": window.FONTSIZE * 0.16
				}
			},
			"splitLine": {
				"show": false
			},
			"itemStyle": {
				"normal": {
					"color": "#515254"
				}
			},
			"title": {
				"show": false,
				"offsetCenter": [0, "100%"]
			},
			"pointer": {
				"show": true,
				"length": "60%",
				"width": 3
			},
			"detail": {
				"show": false
			},
			"data": [{
				"name": "头寸",
				"value": 948.12
			}]
		}]
	}
	var echartsContainer = echarts.init($("#chart3").get(0));
	echartsContainer.setOption(option3);

	// 净资产收益率
	var option4 = {
		"legend": {
			"show": false
		},
		"grid": {},
		"title": {
			"textStyle": {
				"color": "#f3374b",
				"fontSize": window.FONTSIZE * 0.30, //在设计图上改字体是40px，750px的宽度比例
				"fontWeight": "normal"
			},
			"x": "center",
			"y": "35%",
			"text": "48.15%",
			"itemGap": 2,
			"padding": [0, 5]
		},
		"calculable": true,
		"series": [{
			"name": "总量",
			"type": "pie",
			"z": 0,
			"center": ["50%", "40%"],
			"radius": ["55%", "72%"],
			"data": [{
				"value": 3,
				"name": "年度累计",
				"itemStyle": {
					"normal": {
						"color": "#f39800"
					}
				},
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": false
			}, {
				"value": 2,
				"name": "年度预算",
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": false,
				"itemStyle": {
					"normal": {
						"color": "#00b7ee"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart4").get(0));
	echartsContainer.setOption(option4);

	// 资产周转率
	var option5 = {
		"legend": {
			"show": false
		},
		"grid": {},
		"title": {
			"textStyle": {
				"color": "#f3374b",
				"fontSize": window.FONTSIZE * 0.30, //在设计图上改字体是40px，750px的宽度比例
				"fontWeight": "normal"
			},
			"x": "center",
			"y": "35%",
			"text": "48.15%",
			"itemGap": 2,
			"padding": [0, 5]
		},
		"calculable": true,
		"series": [{
			"name": "总量",
			"type": "pie",
			"z": 0,
			"center": ["50%", "40%"],
			"radius": ["55%", "72%"],
			"data": [{
				"value": 3,
				"name": "年度累计",
				"itemStyle": {
					"normal": {
						"color": "#f39800"
					}
				},
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": false
			}, {
				"value": 2,
				"name": "年度预算",
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": false,
				"itemStyle": {
					"normal": {
						"color": "#00b7ee"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart5").get(0));
	echartsContainer.setOption(option5);

	// 资产负债率
	var option6 = {
		"legend": {
			"show": false
		},
		"grid": {},
		"title": {
			"textStyle": {
				"color": "#f3374b",
				"fontSize": window.FONTSIZE * 0.30, //在设计图上改字体是40px，750px的宽度比例
				"fontWeight": "normal"
			},
			"x": "center",
			"y": "45%",
			"text": "48.15%",
			"itemGap": 2,
			"padding": [0, 5]
		},
		"calculable": true,
		"series": [{
			"name": "总量",
			"type": "pie",
			"z": 0,
			"center": ["50%", "50%"],
			"radius": ["35", "95%"],
			"data": [{
				"value": 3,
				"name": "年度累计",
				"itemStyle": {
					"normal": {
						"color": "#f39800"
					}
				},
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": false
			}, {
				"value": 2,
				"name": "年度预算",
				"tooltip": {
					"show": true
				},
				"label": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"labelLine": {
					"normal": {
						"show": false
					},
					"emphasis": {
						"show": false
					}
				},
				"hoverAnimation": false,
				"itemStyle": {
					"normal": {
						"color": "#00b7ee"
					}
				}
			}]
		}],
		"tooltip": {
			"show": true
		}
	}
	var echartsContainer = echarts.init($("#chart6").get(0));
	echartsContainer.setOption(option6);

});