// 第一行可滑动关联指标
var swiper = new Swiper('.relative_index', {
	slidesPerView: 2.2,
	spaceBetween: 15,
	freeMode: true
});

$(document).ready(function() {

	// 目标达成情况
	var option = {
		tooltip: {
			formatter: "{a} <br/>{b} : {c}%"
		},
		toolbox: {
			show: false,
			feature: {
				mark: {
					show: true
				},
				restore: {
					show: true
				},
				saveAsImage: {
					show: true
				}
			}
		},
		series: [{
			name: '完成率',
			type: 'gauge',
			center: ["50%", "50%"],
			radius: "90%",
			splitNumber: 10, // 分割段数，默认为5
			axisLine: { // 坐标轴线
				lineStyle: { // 属性lineStyle控制线条样式
					color: [
						[0.2, '#08c61e'],
						[0.7, '#fcdc08'],
						[1, '#ff5454']
					],
					width: 5
				}
			},
			axisTick: { // 坐标轴小标记
				splitNumber: 10, // 每份split细分多少段
				length: 0, // 属性length控制线长
				lineStyle: { // 属性lineStyle控制线条样式
					color: 'auto'
				}
			},
			axisLabel: { // 坐标轴文本标签，详见axis.axisLabel
				textStyle: { // 其余属性默认使用全局文本样式，详见TEXTSTYLE
					color: 'auto'
				}
			},
			splitLine: { // 分隔线
				show: true, // 默认显示，属性show控制显示与否
				length: 14, // 属性length控制线长
				lineStyle: { // 属性lineStyle（详见lineStyle）控制线条样式
					color: 'auto'
				}
			},
			pointer: {
				width: 4,
				length: '60%'
			},
			title: {
				show: true,
				// y:"bottom",
				offsetCenter: [0, '100%'], // x, y，单位px
				textStyle: { // 其余属性默认使用全局文本样式，详见TEXTSTYLE
					color: '#b5c9fa',
					fontSize: 18,

				},
			},
			detail: {
				formatter: '{value}%',
				textStyle: { // 其余属性默认使用全局文本样式，详见TEXTSTYLE
					color: 'auto',
					fontSize: 18,
				},
				offsetCenter: [0, '55%']
			},
			data: [{
				value: 49,
				name: '海航集团'
			}]
		}]
	};

	var echartsContainer = echarts.init($("#chart1").get(0));
	echartsContainer.setOption(option);

	// 产业集团
	function getOption(i) {
		return {
			tooltip: {
				formatter: "{a} <br/>{b} : {c}%"
			},
			toolbox: {
				show: false,
				feature: {
					mark: {
						show: true
					},
					restore: {
						show: true
					},
					saveAsImage: {
						show: true
					}
				}
			},
			series: [{
				name: '完成率',
				type: 'gauge',
				center: ["50%", "50%"],
				radius: "80%",
				splitNumber: 10, // 分割段数，默认为5
				axisLine: { // 坐标轴线
					lineStyle: { // 属性lineStyle控制线条样式
						color: [
							[0.2, '#08c61e'],
							[0.7, '#fcdc08'],
							[1, '#ff5454']
						],
						width: 5
					}
				},
				axisTick: { // 坐标轴小标记
					splitNumber: 10, // 每份split细分多少段
					length: 0, // 属性length控制线长
					lineStyle: { // 属性lineStyle控制线条样式
						color: 'auto'
					}
				},
				axisLabel: { // 坐标轴文本标签，详见axis.axisLabel
					textStyle: { // 其余属性默认使用全局文本样式，详见TEXTSTYLE
						color: 'auto',
						fontSize: 7
					}
				},
				splitLine: { // 分隔线
					show: true, // 默认显示，属性show控制显示与否
					length: 10, // 属性length控制线长
					lineStyle: { // 属性lineStyle（详见lineStyle）控制线条样式
						color: 'auto'
					}
				},
				pointer: {
					width: 4,
					length: '60%'
				},
				title: {
					show: true,
					// y:"bottom",
					offsetCenter: [0, '100%'], // x, y，单位px
					textStyle: { // 其余属性默认使用全局文本样式，详见TEXTSTYLE
						color: '#b5c9fa',
						fontSize: 12,

					},
				},
				detail: {
					formatter: '{value}%',
					textStyle: { // 其余属性默认使用全局文本样式，详见TEXTSTYLE
						color: 'auto',
						fontSize: 12,
					},
					offsetCenter: [0, '55%']
				},
				data: [{
					value: [10, 80, 50, 70, 90, 70, 90][i],
					name: ["海航科技", "海航现代物流", "海航实业", "海航资本", "海航新媒体", "海航创新金融", "海航xx"][i]
				}]
			}]
		};
	}

	$(".item").each(function(i, ele) {
		var echartsContainer = echarts.init(ele);
		echartsContainer.setOption(getOption(i));
	});

	// 时间线图
	var option2 = {
		"legend": {
			"data": ["2017", "2018", "2018全年目标"]
		},
		"grid": {
			"top": "15%",
			"left": "5%",
			"right": "5%",
			"bottom": "2%",
			"containLabel": true
		},
		"xAxis": {
			"type": "category",
			"data": ["1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月"],
			axisLabel: {
				interval: 0,
				rotate: 0,
				margin: 10,
				textStyle: {
					color: "#84878e"
				}
			},
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		},
		"yAxis": {
			"type": "value",
			"name": "%",
			"position": "left",
			"splitNumber": 5,
			"splitLine": {
				"show": true
			},
			"axisLabel": {
				"textStyle": {
					color: "#84878e"
				}
			},
			axisLine: {
				lineStyle: {
					color: "#84878e"
				}
			}
		},
		"series": [{
			"name": "2017",
			"type": "line",
			"showSymbol": true,
			"smooth": true,
			"symbolSize": 5,
			"symbol": "emptyCircle",
			"itemStyle": {
				"normal": {
					"color": "#C8E0F0"
				}
			},
			"data": [0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.22, 0.33, 0.54, 0.1, 0.5]
		}, {
			"name": "2018",
			"type": "line",
			"showSymbol": true,
			"smooth": true,
			"symbolSize": 5,
			"symbol": "emptyCircle",
			"itemStyle": {
				"normal": {
					"color": "#f3374b"
				}
			},
			"data": [0.2, 0.5, 0.34, 0.15, 0.96, 0.27, 0.28, 0.34, 0.54, 0.98, 0.03, 0.29, 0.22, 0.99]
		}, {
			"name": "2018全年目标",
			"type": "line",
			"showSymbol": true,
			"smooth": true,
			"symbolSize": 5,
			"symbol": "emptyCircle",
			"itemStyle": {
				"normal": {
					"color": "#f39800"
				}
			},
			"data": [0.32, 0.63, 0.84, 0.75, 0.26, 0.17, 0.08, 0.11, 0.29, 0.49, 0.49, 0.44]
		}],
		"tooltip": {
			"show": true,
			"trigger": "axis"
		}
	}
	var echartsContainer = echarts.init($("#chart2").get(0));
	echartsContainer.setOption(option2);

});