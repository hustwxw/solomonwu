// 第一行可滑动关联指标
var swiper = new Swiper('.relative_index', {
	slidesPerView: 2.2,
	spaceBetween: 15,
	freeMode: true
});

$(document).ready(function() {

	var option = {
		backgroundColor: '#ffffff',
		legend: {
			show: false
		},
		grid: {
			left: '1%',
			right: '12%',
			bottom: '10%',
			top: '5%',
			containLabel: true
		},

		tooltip: {
			show: "true",
			trigger: 'axis',
			axisPointer: { // 坐标轴指示器，坐标轴触发有效
				type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
			}
		},
		xAxis: {
			type: 'value',
			axisTick: {
				show: false
			},
			axisLine: {
				show: true,
				lineStyle: {
					color: '#84878e',
				}
			},
			splitLine: {
				show: false
			},
			name: '亿元'
		},
		yAxis: [{
				type: 'category',
				axisTick: {
					show: false
				},
				axisLine: {
					show: true,
					lineStyle: {
						color: '#84878e',
					}
				},
				data: ['海航资本', '海航实业', '海航现代物流', '海航科技', '海航创新金融', '海航新传媒'].reverse()
			}, {
				type: 'category',
				axisLine: {
					show: false
				},
				axisTick: {
					show: false
				},
				axisLabel: {
					show: false
				},
				splitArea: {
					show: false
				},
				splitLine: {
					show: false
				},
				data: ['海航资本', '海航实业', '海航现代物流', '海航科技', '海航创新金融', '海航新传媒'].reverse()
			},

		],
		series: [{
				name: '资产总额',
				type: 'bar',
				yAxisIndex: 1,

				itemStyle: {
					normal: {
						show: true,
						color: '#f3374b',
						borderWidth: 0
					}
				},
				barGap: '0%',
				barCategoryGap: '50%',
				data: [120, 132, 101, 134, 90, 230]
			}

		]
	};

	var echartsContainer = echarts.init($("#chart").get(0));
	echartsContainer.setOption(option);

});